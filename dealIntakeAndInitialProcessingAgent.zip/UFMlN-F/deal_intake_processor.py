# main.py - Google Cloud Function to process QuickLiqi deal intake forms.

import os
import json
import logging
import gspread
from google.oauth2.service_account import Credentials

# --- Configuration ---

# Configure logging to output to Cloud Logging.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Google API & Sheets Configuration ---

# Define the scopes required for Google Sheets and Drive APIs.
# This allows the script to read from and write to Google Sheets.
SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive.file'
]

# The name of the Master Tracking System Google Sheet.
# IMPORTANT: This must exactly match the name of your target Google Sheet.
MASTER_SHEET_NAME = "QuickLiqi - Master Tracking System"

# The name of the specific tab (worksheet) where new deals will be appended.
# IMPORTANT: This must exactly match the name of your target worksheet.
PIPELINE_WORKSHEET_NAME = "Deal Pipeline"

# --- Main Cloud Function ---

def process_deal_intake(event, context):
    """
    Cloud Function triggered by a new row added to a Google Sheet from a Form.
    Parses the form response and appends a structured row to the Master Tracking System.

    Args:
        event (dict): The event payload from the Google Cloud Trigger.
                      This is expected to contain the form submission data.
        context (google.cloud.functions.Context): Metadata for the event.
    """
    logging.info(f"Function triggered by event ID: {context.event_id}, type: {context.event_type}")

    try:
        # --- 1. Authenticate with Google Sheets ---
        
        # In a live Google Cloud Function environment, service account credentials
        # can be accessed from a mounted file or environment variables.
        # For local testing, 'google_creds.json' is expected in the same directory.
        # For deployment, upload the JSON key with your function and reference it,
        # or rely on the function's runtime service account.
        
        # The gspread library simplifies authentication. It will look for the
        # GOOGLE_APPLICATION_CREDENTIALS environment variable if it's set.
        # If not, we try to load from a local JSON file if it exists.
        
        creds_json_str = os.environ.get('GOOGLE_CREDS_JSON')
        if creds_json_str:
            logging.info("Loading credentials from environment variable.")
            creds_info = json.loads(creds_json_str)
            creds = Credentials.from_service_account_info(creds_info, scopes=SCOPES)
        else:
            # Fallback for local development if 'google_creds.json' is present.
            # In production GCF, you should set the GOOGLE_CREDS_JSON env var.
            creds_path = 'google_creds.json'
            logging.warning(f"Could not find GOOGLE_CREDS_JSON env var. Falling back to local file: {creds_path}")
            if not os.path.exists(creds_path):
                logging.error("Service account credentials file not found and env var not set. Aborting.")
                return 'Authentication Error: Credentials not found.', 500
            creds = Credentials.from_service_account_file(creds_path, scopes=SCOPES)
        
        client = gspread.authorize(creds)
        
        # --- 2. Parse Incoming Form Data ---
        
        # The 'event' object for a Google Sheets trigger contains 'values'.
        # 'values' is a list of the cell values in the new row.
        if 'values' not in event:
            logging.error("Event payload does not contain 'values' key. Cannot process.")
            return 'Bad Request: Missing form values in event payload.', 400
            
        form_data = event['values']
        logging.info(f"Received form data with {len(form_data)} fields.")
        
        # Based on "QuickLiqi: Deal Intake Form Template"
        # The order of fields in `form_data` list is crucial.
        # Index:  Expected Field:
        # 0       Timestamp
        # 1       Your Full Name or Company Name
        # 2       Best Contact Email
        # 3       Best Contact Phone Number (Optional)
        # 4       Full Property Street Address
        # 5       City
        # 6       State
        # 7       Zip Code
        # 8       Property Type
        # 9       Bedrooms
        # 10      Bathrooms
        # 11      Square Footage (SQFT)
        # 12      After Repair Value (ARV)
        # 13      Your Asking Price (Assignment)
        # 14      Estimated Repair Costs
        # 15      Link to Photos/Videos
        # 16      Access Details
        # 17      Additional Notes or Unique Selling Points (Optional)
        # Note: We assume the form is not set to "Collect Emails" automatically by Google,
        # so submitter email is not at index 1. If it is, indices will shift.

        # Basic validation
        if len(form_data) < 15:
            logging.error(f"Insufficient data received. Expected at least 15 fields, got {len(form_data)}.")
            return 'Bad Request: Incomplete form data.', 400

        # --- 3. Map Form Data to Sheet Columns ---
        
        # This mapping aligns the form data to the "Deal Pipeline" worksheet structure.
        # Empty strings ('') are used as placeholders for columns that are not
        # filled at intake (e.g., 'Close Date', 'Final Assignment Fee').
        
        notes_list = [
            f"Photos/Videos: {form_data[15] if len(form_data) > 15 and form_data[15] else 'N/A'}",
            f"Access Details: {form_data[16] if len(form_data) > 16 and form_data[16] else 'N/A'}",
            f"Additional Info: {form_data[17] if len(form_data) > 17 and form_data[17] else 'N/A'}"
        ]
        combined_notes = "\n".join(notes_list)
        
        new_row = [
            '',                      # A: Deal_ID (leave blank for sheet formula, e.g., ="DEAL-"&ROW())
            form_data[0],            # B: Submission Date (from form timestamp)
            form_data[4],            # C: Property Address
            form_data[5],            # D: City
            form_data[6],            # E: State
            form_data[7],            # F: Zip
            form_data[8],            # G: Property Type
            form_data[9],            # H: Bed
            form_data[10],           # I: Bath
            form_data[11],           # J: SQFT
            form_data[12],           # K: ARV
            form_data[13],           # L: Asking Price
            form_data[14],           # M: Estimated Repairs
            '',                      # N: Projected Fee
            form_data[1],            # O: JV Partner Name
            form_data[2],            # P: JV Partner Contact (Email)
            'New',                   # Q: Status (initial status)
            '',                      # R: Close Date
            '',                      # S: Final Assignment Fee
            '',                      # T: QuickLiqi Share
            combined_notes,          # U: Notes
            '',                      # V: Intake Form Link (Requires form setting to capture edit URL)
        ]

        logging.info(f"Prepared new row for worksheet: {new_row}")
        
        # --- 4. Append Data to Google Sheet ---
        
        logging.info(f"Opening Google Sheet: '{MASTER_SHEET_NAME}'")
        spreadsheet = client.open(MASTER_SHEET_NAME)
        
        logging.info(f"Accessing worksheet: '{PIPELINE_WORKSHEET_NAME}'")
        worksheet = spreadsheet.worksheet(PIPELINE_WORKSHEET_NAME)
        
        worksheet.append_row(new_row, value_input_option='USER_ENTERED')
        
        logging.info("Successfully appended new row to the Deal Pipeline.")
        
        return 'Success: Deal processed and added to pipeline.', 200

    except gspread.exceptions.SpreadsheetNotFound:
        logging.error(f"CRITICAL ERROR: The Google Sheet '{MASTER_SHEET_NAME}' was not found.")
        return 'Server Error: Master spreadsheet not found.', 500
        
    except gspread.exceptions.WorksheetNotFound:
        logging.error(f"CRITICAL ERROR: The worksheet '{PIPELINE_WORKSHEET_NAME}' was not found in the sheet.")
        return 'Server Error: Pipeline worksheet not found.', 500
        
    except Exception as e:
        # Catch-all for any other unexpected errors.
        logging.exception("An unexpected error occurred during execution.")
        return f'Server Error: An internal error occurred: {e}', 500
